# Changelog
- v0.1.0: Estrutura inicial do repositório, notebook importado, dados de amostra e documentação.
