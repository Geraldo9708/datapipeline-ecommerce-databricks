# Databricks notebook source
# Projeto portfólio: Pipeline E-commerce (Bronze → Silver → Gold)
# Observação: Este arquivo foi exportado do Databricks e organizado para GitHub.

# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://moodle.df.senac.br/faculdade/pluginfile.php/1/theme_lambda/logo/1716924091/Logo-SENAC-PNG.png" style="width: 300px; height: 150px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##Identificação
# MAGIC
# MAGIC **Aluno:** Elivânio Geraldo
# MAGIC
# MAGIC **Turma:** Data Science e IA
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##Cenário
# MAGIC
# MAGIC Uma empresa que vende produtos pela internet gostaria de conhecer melhor o perfil de seus clientes para impulsionar suas vendas. Além de fazer um acompanhamento do que está sendo vendido no site.
# MAGIC
# MAGIC A área de marketing tem necessidade de explorar as informações sobre as vendas de produtos para sugerir promoções, descontos, vendas casadas e novos produtos aos seus clientes. E, também, realizar campanhas a públicos específicos. 
# MAGIC
# MAGIC Além disso, há gestores da empresa que necessitam monitorar as vendas em _near real-time_
# MAGIC
# MAGIC Todo evento/ação do usuário ao comprar no site é publicado em um serviço de mensageria, onde se pode capturar informações de carrinho de compras e vendas realizadas.
# MAGIC
# MAGIC Seu papel é criar um _pipeline_ para extração e limpeza desses dados a fim de atender essas necessidades.
# MAGIC
# MAGIC Utilizando como fonde de dados o arquivo _ecommerce.json_, faça as atividades.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Atividade - Carga de Dados
# MAGIC
# MAGIC - Criar e carregar uma tabela chamada _`ecommerce_bronze`_, com os dados _raw_ do diretório `/Volumes/senac/default/ecommerce`
# MAGIC - Criar e carregar uma tabela chamada _`ecommerce_silver`_, com base na tabela da camada anterior, atendendo os seguintes requisitos:
# MAGIC   - Colunas: `device, event_name, event_previous_timestamp, event_timestamp, city (geo.city), state (geo.state), traffic_source, user_id e todas as colunas do campo items (items.col1, items.col2, ..., items.colN)`
# MAGIC   - As colunas do tipo _epoch_ devem ser convertidas para _timestamp_
# MAGIC   - A coluna items deve ser _exploded_. Com há valores nulos, dê uma olhada em <a hfref='https://docs.databricks.com/en/sql/language-manual/functions/explode_outer.html'>_explode_outer_</a>
# MAGIC - Criar e carregar uma tabela chamada _cidades_gold_ com os dados distintos referentes a localização dos eventos (_geo_)
# MAGIC - Criar e carregar uma tabela chamada _produtos_gold_ com as informações distintas sobre os itens vendidos no _ecommerce_: `identificador, nome, preço unitário`
# MAGIC - Criar e carregar uma tabela chamada _vendas_gold_ que contenha o `user_id, coupon, item_id, event_date (derivado event_timestamp - formato 'yyy-MM-dd'), city, state`, agregando a quantidade (_quantity_) e o valor total de venda do produto
# MAGIC   - Lembrando que o valor de venda (_total_) é o preço unitário (_price_in_usd_) x quantidade 
# MAGIC   - Apenas as compras que foram efetivadas (`event_name = finalize`)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM read_files('dbfs:/Volumes/workspace/default/ecommerce', format => 'text')
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE ecommerce_bronze AS
# MAGIC SELECT * 
# MAGIC FROM read_files('dbfs:/Volumes/workspace/default/ecommerce', format => 'text');

# COMMAND ----------

# MAGIC %sql
# MAGIC select schema_of_json('{"device":"Windows","ecommerce":{"purchase_revenue_in_usd":535.5,"total_item_quantity":1,"unique_items":1},"event_name":"finalize","event_previous_timestamp":1593768254039366,"event_timestamp":1593769317184993,"geo":{"city":"Roseville","state":"CA"},"items":[{"coupon":"NEWBED10","item_id":"M_STAN_T","item_name":"Standard Twin Mattress","item_revenue_in_usd":535.5,"price_in_usd":595.0,"quantity":1}],"traffic_source":"email","user_first_touch_timestamp":1593438329240378,"user_id":"UA000000106028539"}') as schema;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW events AS (
# MAGIC
# MAGIC     SELECT from_json(value, 'STRUCT<device STRING, ecommerce STRUCT<purchase_revenue_in_usd DOUBLE, total_item_quantity INT, unique_items INT>, event_name STRING, event_previous_timestamp BIGINT, event_timestamp BIGINT, geo STRUCT<city STRING, state STRING>, items ARRAY<STRUCT<coupon STRING, item_id STRING, item_name STRING, item_revenue_in_usd DOUBLE, price_in_usd DOUBLE, quantity INT>>, traffic_source STRING, user_first_touch_timestamp BIGINT, user_id STRING>') AS json_result
# MAGIC     FROM ecommerce_bronze
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE ecommerce_silver AS
# MAGIC SELECT
# MAGIC parsed.device,
# MAGIC parsed.event_name,
# MAGIC CAST(parsed.event_previous_timestamp / 1000000 AS TIMESTAMP) AS event_previous_timestamp,
# MAGIC CAST(parsed.event_timestamp / 1000000 AS TIMESTAMP) AS event_timestamp,
# MAGIC parsed.geo.city AS city,
# MAGIC parsed.geo.state AS state,
# MAGIC parsed.traffic_source,
# MAGIC parsed.user_id,
# MAGIC item.coupon,
# MAGIC item.item_id,
# MAGIC item.item_name,
# MAGIC item.item_revenue_in_usd,
# MAGIC item.price_in_usd,
# MAGIC item.quantity
# MAGIC FROM (
# MAGIC   SELECT from_json(value, 'STRUCT<device STRING, ecommerce STRUCT<purchase_revenue_in_usd DOUBLE, total_item_quantity INT, unique_items INT>, event_name STRING, event_previous_timestamp BIGINT, event_timestamp BIGINT, geo STRUCT<city STRING, state STRING>, items ARRAY<STRUCT<coupon STRING, item_id STRING, item_name STRING, item_revenue_in_usd DOUBLE, price_in_usd DOUBLE, quantity INT>>, traffic_source STRING, user_first_touch_timestamp BIGINT, user_id STRING>') AS parsed
# MAGIC   FROM ecommerce_bronze
# MAGIC )
# MAGIC
# MAGIC LATERAL VIEW OUTER explode(parsed.items) AS item;
# MAGIC
# MAGIC select * from ecommerce_silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE cidades_gold AS 
# MAGIC SELECT DISTINCT city, state FROM ecommerce_silver
# MAGIC
# MAGIC WHERE city IS NOT NULL AND state IS NOT NULL;
# MAGIC
# MAGIC SELECT * FROM cidades_gold;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE produtos_gold AS
# MAGIC SELECT DISTINCT item_id, item_name, price_in_usd FROM ecommerce_silver
# MAGIC
# MAGIC WHERE item_id IS NOT NULL AND item_name IS NOT NULL AND price_in_usd IS NOT NULL;
# MAGIC
# MAGIC SELECT * FROM produtos_gold;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT event_name FROM ecommerce_silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT event_name, COUNT(*)
# MAGIC FROM ecommerce_silver
# MAGIC GROUP BY event_name
# MAGIC ORDER BY COUNT(*) DESC;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE vendas_gold AS
# MAGIC SELECT
# MAGIC DATE_FORMAT(event_timestamp, 'yyyy-MM-dd') AS event_date,
# MAGIC user_id,
# MAGIC item_id,
# MAGIC coupon,
# MAGIC city, 
# MAGIC state,
# MAGIC quantity,
# MAGIC price_in_usd * quantity AS total
# MAGIC FROM ecommerce_silver
# MAGIC WHERE event_name = 'finalize';
# MAGIC
# MAGIC SELECT * FROM vendas_gold;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT event_name, COUNT(*)
# MAGIC FROM ecommerce_silver
# MAGIC GROUP BY event_name
# MAGIC HAVING COUNT(*) = 10719;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validação
# MAGIC
# MAGIC Execute as células abaixo para verificar possíveis erros na carga dos dados

# COMMAND ----------

def check_table_results(table_name, num_rows, column_names):
    assert spark.table(table_name), f"Tabela {table_name} inexistente"
    assert set(spark.table(table_name).columns) == set(column_names), f"As colunas da tabela {table_name} nao foram criadas conforme orientacao"
    assert spark.table(table_name).count() == num_rows, f"A tabela {table_name} deveria ter {num_rows} registros"

# COMMAND ----------

check_table_results("ecommerce_bronze", 500000, ['value'])
check_table_results("ecommerce_silver", 515101, ['device', 'event_name', 'event_previous_timestamp', 'event_timestamp', 'city', 'state', 'traffic_source', 'user_id', 'coupon' , 'item_id', 'item_name', 'item_revenue_in_usd', 'price_in_usd', 'quantity' ])
check_table_results("cidades_gold", 6549, ['city'  , 'state'])
check_table_results("produtos_gold", 12, ['item_id' , 'item_name' , 'price_in_usd'])
check_table_results("vendas_gold", 10719, ['user_id' , 'coupon' , 'item_id', 'event_date', 'city' , 'state' , 'quantity', 'total'])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Atividade - Consulta aos dados
# MAGIC
# MAGIC Com base nas tabelas carregadas na camada _gold_, crie consultas que respondam os questionamentos abaixo, em células separadas.
# MAGIC
# MAGIC 1. Qual foi o valor total de vendas, onde foi utilizado algum cupom?
# MAGIC 1. Faça um _ranking_ dos 5 produtos mais vendidos, em termos de quantidade, em junho/2020. Projete o nome do produto, a quantidade vendida e o valor total.
# MAGIC 1. Qual são os quatro nomes de cidades que mais aparecem em estados diferentes?
# MAGIC 1. Monte uma consulta, mostrando seu resultado, onde cada `item_id` é transposto para uma nova coluna. Agrupe por cidade e estado. Cada coluna deve ser pivoteada com base na quantidade e total da venda.
# MAGIC

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC SELECT 
# MAGIC     SUM(total) AS total_vendas_coupon
# MAGIC FROM vendas_gold
# MAGIC WHERE TRIM(coupon) != '' AND coupon IS NOT NULL
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   p.item_name,
# MAGIC   SUM(v.quantity) AS quantidade_vendida,
# MAGIC   SUM(v.total) AS valor_total
# MAGIC FROM vendas_gold v
# MAGIC JOIN produtos_gold p ON v.item_id = p.item_id
# MAGIC WHERE v.event_date BETWEEN '2020-06-01' AND '2020-06-30'
# MAGIC GROUP BY p.item_name
# MAGIC ORDER BY quantidade_vendida DESC
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   city,
# MAGIC   COUNT(DISTINCT state) AS qtd_estados
# MAGIC FROM vendas_gold
# MAGIC GROUP BY city
# MAGIC ORDER BY qtd_estados DESC
# MAGIC LIMIT 4;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT item_id
# MAGIC FROM vendas_gold
# MAGIC LIMIT 10;
# MAGIC