# Diretrizes de testes (futuros)

- **Contratos**: validar presença e tipo de colunas essenciais em Silver e Gold.
- **Contagem por camada**: checar se a prata e o ouro refletem a mesma cardinalidade esperada após deduplicação.
- **Reprocessamento**: simular rodar o pipeline 2x e garantir idempotência (sem duplicar).
- **Consultas**: validar consultas analíticas (top N, total por período) com amostras pequenas.
