# Diagrama e anotações

```mermaid
erDiagram
    VENDAS_GOLD ||--o{ ITENS_VENDA : contem
    VENDAS_GOLD }o--|| CIDADES_GOLD : ocorre_em
    VENDAS_GOLD }o--|| PRODUTOS_GOLD : referencia

    CIDADES_GOLD {
      string city
      string state
    }

    PRODUTOS_GOLD {
      string item_id
      string item_name
      float price_in_usd
    }

    VENDAS_GOLD {
      date event_date
      string state
      string city
      string coupon
      string item_id
      int quantity
      float total
    }
```
